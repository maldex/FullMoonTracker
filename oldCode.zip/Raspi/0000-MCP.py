#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import simplejson as json
import time, requests, urllib.parse, threading, logging
from pprint import pprint

logging.basicConfig(level=logging.DEBUG)
logging.getLogger("urllib3.connectionpool").setLevel(logging.INFO)

raspiUrl = "http://127.0.0.1"
joyServiceUrl = raspiUrl + ":6662/data"
motorServiceUrl = raspiUrl + ":6664/data"
ocvServiceUrl = raspiUrl + ":6661"
ocvServiceParams = "/get?dp=1.6&minDist=16&minRad=64&maxRad=2&mode=get fresh analysis&width=1024&height=768"

def synchronized_method(method):
    """simple way of locking annotated method calls within different threads"""
    outer_lock = threading.Lock()
    lock_name = "__" + method.__name__ + "_lock" + "__"
    def sync_method(self, *args, **kws):
        with outer_lock:
            if not hasattr(self, lock_name): setattr(self, lock_name, threading.Lock())
            lock = getattr(self, lock_name)
            with lock:
                return method(self, *args, **kws)
    return sync_method


class RefreshOcv(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self._set_aliveness(False)
        self.set_data({"timestamp": 0})

    @synchronized_method
    def _get_aliveness(self):
        return self._alive

    @synchronized_method
    def _set_aliveness(self, value):
        self._alive = value

    @synchronized_method
    def set_data(self,data):
        self.data = data

    @synchronized_method
    def get_data(self):
        return self.data

    def run(self):
        self._set_aliveness(True)
        while self._get_aliveness():
            try:
                trigger = requests.get(ocvServiceUrl + ocvServiceParams)
                ocvData = requests.get(ocvServiceUrl + "/last.json")
                self.set_data(json.loads(ocvData.text))
            except requests.exceptions.ConnectionError as e:
                time.sleep(1)
            time.sleep(0.01)


if __name__ == "__main__":

    logging.info("hi, starting opencv reader thread")
    refresher = RefreshOcv()
    refresher.start()

    last_ocv_timestamp = 0

    logging.info("entering global loop")
    while True:
        response = requests.get(joyServiceUrl)
        joyData = json.loads(response.text)
        motorPostData = {'h_steps': 0, 'v_steps': 0}

        ### open cv circle detection handling
        if refresher.get_data()['timestamp'] != last_ocv_timestamp:
            last_ocv_timestamp = refresher.get_data()['timestamp']
            if "biggest" in refresher.get_data():
                if refresher.get_data()['biggest']['dX'] > 1000 or refresher.get_data()['biggest']['dY'] > 1000:
                    logger.warn("circle data too big skipping")
                    continue

                if abs(refresher.get_data()['biggest']['dX']) > 15:
                    motorPostData['h_steps'] = refresher.get_data()['biggest']['dX'] * -2

                if abs(refresher.get_data()['biggest']['dY']) > 15:
                    motorPostData['v_steps'] = refresher.get_data()['biggest']['dY'] * 2

                if motorPostData['v_steps'] != 0 or motorPostData['h_steps'] != 0:
                    logging.info("circle data " + str(refresher.get_data()["biggest"]))

        ### joystick data handling
        if joyData['buttons'][0] or joyData['buttons'][1] or joyData['buttons'][2] or joyData['buttons'][3]:
            logging.info("joystick data " + str(joyData['axes']) + " " + str(joyData['axes']))
            speed = 0
            if joyData['buttons'][0]: speed = 100
            elif joyData['buttons'][1]: speed = 500
            elif joyData['buttons'][2]: speed = 1000
            elif joyData['buttons'][3]: speed = 2000

            h_steps = int(-1 * joyData['axes'][0] * speed)
            v_steps = int(joyData['axes'][1] * speed)

            motorPostData = {'h_steps': h_steps, 'v_steps': v_steps}



        ### moving the motors
        if motorPostData['h_steps'] !=0 or motorPostData['v_steps'] !=0:
            x = requests.post(motorServiceUrl, json=motorPostData)
            logging.info("motor return data " + str(json.loads(x.text)))



        time.sleep(0.01)