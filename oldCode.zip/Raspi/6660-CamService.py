#!/usr/bin/python3
# -*- coding: utf-8 -*-

# sudo pip3 install simplejson flask yattag hurry.filesize

from pprint import pprint

import os, sys, io, time

from flask import Flask, request, Response, render_template, send_from_directory, send_file, abort, redirect
from yattag import Doc
import logging
import picamera
from datetime import datetime
from hurry.filesize import size    # pip install hurry.filesize
# from magic import Magic
# from stat import *
from urllib.request import Request, urlopen  # Python 3
import urllib.error
import simplejson as json
linesep = os.linesep
localhost = "rpi-d9c44813"

app = Flask(__name__, static_url_path='')
app.logger.setLevel(logging.DEBUG)
logging.basicConfig(level=logging.DEBUG)


@app.route("/")
def index():
    doc, tag, text = Doc().tagtext()

    with tag('h2'):
        text("Get Data Area")

    with tag('big'):
        with tag('a', ('href', '/pic.jpeg')):
            text('get full pic')
        text(' - ')
        with tag('a', ('href', '/pic.jpeg?h=1280&w=720')):
            text('get small pic')

    with tag('hr'):
        pass
    with tag('h2'):
        text("Admin Area")

    if not 'mode' in request.args:
        with tag('table'):
            with tag('tr'):
                with tag('form', ('method', 'get')):
                    with tag('td'):
                        if MyCam.get_preview(): v = "stop preview"
                        else: v = "start preview"
                        with tag('input', ('type', 'submit'), ('name', 'mode'), ('value', v)):
                            pass
                    with tag('td'):
                        with tag('input', ('type', 'submit'), ('name', 'mode'), ('value', 'EXIT')):
                            pass
                    with tag('td'):
                        with tag('input', ('type', 'submit'), ('name', 'mode'), ('value', 'REBOOT')):
                            pass

    else: # mode was specified

        # if request.args['mode'] in ['redings','exit','reboot']:
        if request.args['mode'].isupper():
            with tag('h1'):
                text("ARE U SURE?")
            with tag('form', ('method', 'get')):
                with tag('input', ('type', 'submit'), ('name', 'mode'), ('value', request.args['mode'].lower())):
                    pass

        if request.args['mode'] == "reboot":
            os.system('sudo reboot')

        if request.args['mode'] == "exit":
            func = request.environ.get('werkzeug.server.shutdown')
            func()
            os._exit(0)

        if request.args['mode'].endswith("preview"):
            MyCam.set_preview(request.args['mode'].startswith("start"))
            with tag('meta', ('http-equiv', 'refresh'), ('content', '0; url=' + request.environ['PATH_INFO'])):
                pass
            return doc.getvalue()

        if request.args['mode'] == "start preview":
            MyCam.set_preview(True)



    with tag('hr'):
        pass
    with tag('h2'):
        text("request.args")
    with tag('pre'):
        for k,v in request.args.items():
            doc.asis(str(k) + ': ' + str(v) + linesep)


    with tag('hr'):
        pass
    with tag('h2'):
        text("request.environ")
    with tag('pre'):
        for k, v in request.environ.items():
            doc.asis(str(k) + ': ' + str(v) + linesep)
    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')

@app.route("/pic.jpeg")
def get(width=None, height=None):
    if 'w' in request.args:
        width = int(request.args['w'])
    if 'h' in request.args:
        height = int(request.args['h'])
    obj = MyCam.capture(width=width, height=height)
    return Response(obj.getvalue(), mimetype='image/jpeg')


# https://picamera.readthedocs.io/en/release-1.10/api_camera.html
# effects:  none, negative, solarize, sketch, denoise, emboss, oilpaint, hatch, gpen, pastel, watercolor, film, blur, saturation, colorswap, washedout, posterise, colorpoint, colorbalance, cartoon, deinterlace1 und deinterlace2
# awb: off, auto, sunlight, cloudy, shade, tungsten, fluorescent, incandescent, flash, und horizo
# exposure: off, auto, night, nightpreview, backlight, spotlight, sports, snow, beach, verylong, fixedfps, antishake, und firework

class MyPyPiCam(object):
    def __init__(self, device=0, width=3280, height=2464, rotation=0, contrast=0, brightness=50, saturation=0, sharpness=0, effect='none', awb='auto', exposure='auto'):
        self.camera = picamera.PiCamera(device)
        self.camera.resolution = (width, height)
        self.camera.rotation = rotation
        self.camera.brightness = brightness
        self.camera.saturation = saturation
        self.camera.image_effect = effect
        self.camera.sharpness = sharpness
        self.camera.contrast = contrast
        self.camera.awb_mode = awb
        self.camera.exposure_mode = exposure
        self.camera.led = False
        self._preview = False
        self.last_pic = io.BytesIO()
        self.set_preview()
#        self.capture()

    def get_preview(self):
        return self._preview

    def set_preview(self, value=True):
        if value == self.get_preview():
            return None
        self._preview = value
        if value:
            return self.camera.start_preview()
        else:
            return self.camera.stop_preview()

    def capture(self, text=None, width=None, height=None):
        if text is None:
            try:
                text = os.environ['HOSTNAME'].upper()
            except KeyError as e:
                text = os.popen('hostname -s').read().strip().upper()
            try:
                answer = urlopen("http://"+localhost+":6661/", timeout=1)
                text += " - " + json.loads(answer.read())['string']
            except Exception as e:
                logging.warning("Error while reading sensor " + str(e))
            text += " - " + datetime.today().strftime('%Y.%m.%d %H:%M:%S.%f')
        self.set_preview(True)
        start = time.time()
        self.camera.annotate_text = text
        self.camera.annotate_text_size = 36
        try:
            new_pic = io.BytesIO()
            if width is None or height is None:
                self.camera.capture(new_pic, format='jpeg')
            else:
                self.camera.capture(new_pic, format='jpeg', resize=(width, height))
            logging.info("captured %s in %.3f sec" % (size(sys.getsizeof(new_pic)), (time.time() - start)))
            self.last_pic = new_pic
        except picamera.exc.PiCameraValueError as e:
            logging.warning(str(e) + " - using last picture")

        return io.BytesIO(self.last_pic.getvalue())

if __name__ == '__main__':
    logging.info("starting camera")
    MyCam = MyPyPiCam()
    logging.info("starting preview")
   # MyCam.set_preview(True)
    logging.info("starting flask")
    app.run(host='0.0.0.0', port=6660, debug=False)

