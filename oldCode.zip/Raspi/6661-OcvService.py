#!/usr/bin/python3
# -*- coding: utf-8 -*-


import cv2
import numpy
import time
import urllib
import simplejson as json
from datetime import datetime
from urllib.request import Request, urlopen  # Python 3
from pprint import pprint

from flask import Flask, request, Response, render_template, send_from_directory, send_file, abort, redirect
from yattag import Doc
import logging, os
import urllib.error
import simplejson as json

os.environ["DISPLAY"]="poseidon:0"

linesep = os.linesep

app = Flask(__name__, static_url_path='')
app.logger.setLevel(logging.DEBUG)
logging.basicConfig(level=logging.DEBUG)


def from_pic_get_circles(url="http://rpi-c8de:6660/pic.jpeg?w=3280&h=2464", show_preview=True, dp=1.4, minDist=8, minRad=64, maxRad=2):
    resp = urlopen(url)
    image = numpy.asarray(bytearray(resp.read()), dtype="uint8")
    image = cv2.imdecode(image, cv2.IMREAD_COLOR)
    preview = image.copy()

    other_color = (160, 160, 255)
    disp_color = (32, 64, 192)
    text_color = (32, 255, 32)

    cv2.line(preview, (0, int(image.shape[0] / 2)), (image.shape[1], int(image.shape[0] / 2)), (0, 0, 0), 1)
    cv2.line(preview, (int(image.shape[1] / 2), 0), (int(image.shape[1] / 2), image.shape[0]), (0, 0, 0), 1)

    c={
        "dp": dp,
        "minDist_divider": minDist,
        "minRadius_divider": minRad,
        "maxRadius_divider": maxRad
    }

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # detect circles in the image
    stime = time.time()
    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=c['dp'], minDist=int(image.shape[0]/c['minDist_divider']), minRadius=int(image.shape[0]/c['minRadius_divider']), maxRadius=int(image.shape[0]/c['maxRadius_divider']))
    delta = int((time.time() - stime) * 1000 * 1000 ) / 1000

    ret = {
        "config": c,
        "metric": {"picture_size": [image.shape[1], image.shape[0]],
                   "processing_ms": delta,
                   "circles_found": None
                   },
        "circles": [],
        'timestamp': time.time()
    }


    if circles is not None:
        ret['metric']['circles_found'] = len(circles)
        circles = numpy.round(circles[0, :]).astype("int")

        print("found " + str(len(circles)) + " circles in " + str(delta))

        biggest_one = (0,0,0)
        dX, dY = None, None

        # loop over the (x, y) coordinates and radius of the circles
        for (x, y, r) in circles:
            # draw the circle in the output image, then draw a rectangle
            # corresponding to the center of the circle
            print("circle at " + str((x,y,r)))
            cir = (x,y,r)
            ret['circles'].append((int(x), int(y), int(r)))

            # cv2.rectangle(output, (x - 5, y - 5), (x + 5, y + 5), (0, 128, 255), -1)

            # cv2.rectangle(preview, (x - r, y - r), (x + r, y + r), disp_color, 1)
            
            cv2.line(preview, (x - 5, y - 5), (x + 5, y + 5), other_color, 1)
            cv2.line(preview, (x - 5, y + 5), (x + 5, y - 5), other_color, 1)

            cv2.circle(preview, (x, y), r, other_color, 2)


            dX = -int(image.shape[1]/2 - x )
            dY = -int(image.shape[0]/2 - y )
            text = str("X:" + str(x) + ", Y:" + str(y) + ", R:" + str(r))
            cv2.putText(preview, text, (x, y+3), cv2.FONT_HERSHEY_SIMPLEX, .3, other_color, 1, cv2.LINE_AA)
            # text = "dX:" + str(dX) + " dY:" + str(dY)
            # cv2.putText(preview, text, (x, y + 12), cv2.FONT_HERSHEY_SIMPLEX, .3, other_color, 1, cv2.LINE_AA)

            if biggest_one[2] < r:
                biggest_one = (x, y, r, dX, dY)


        ret['biggest'] = { "x": int(biggest_one[0]),
                         "y": int(biggest_one[1]),
                         "r": int(biggest_one[2]),
                         "dX": int(biggest_one[3]), "dY": int(biggest_one[4]) }


        x,y,r,dX,dY = biggest_one
        l = 15
        # cv2.line(preview, (x + r, y + r), (x + r - l, y + r - l), text_color, 2)
        cv2.line(preview, (x - r, y + r), (x, y + r), text_color, 2)
        cv2.line(preview, (x - r, y + r), (x - r, y), text_color, 2)
        # cv2.line(preview, (x - r, y - r), (x - r + l, y - r + l), text_color, 2)
        cv2.line(preview, (x + r, y - r), (x, y - r), text_color, 2)
        cv2.line(preview, (x + r, y - r), (x + r, y), text_color, 2)

        cv2.line(preview, (x - l, y - l), (x + l, y + l), text_color, 2)
        cv2.line(preview, (x - l, y + l), (x + l, y - l), text_color, 2)

        text = str("X:" + str(x) + ", Y:" + str(y) + ", R:" + str(r))
        cv2.putText(preview, text, (x-r, y+r-l), cv2.FONT_HERSHEY_SIMPLEX, .6, text_color, 1, cv2.LINE_AA)
        text = "dX:" + str(dX) + " dY:" + str(dY)
        cv2.putText(preview, text, (x-r, y+r), cv2.FONT_HERSHEY_SIMPLEX, .6, text_color, 1, cv2.LINE_AA)

        print("-----------------")
        # print(json.dumps(ret))

        text = "picture width: " +str(image.shape[1]) + "  height: " + str(image.shape[0]) + ", found " + str(len(circles)) + " circle(s), took " + str(delta) + "ms"
        cv2.putText(preview, text, (10, image.shape[0]-14), cv2.FONT_HERSHEY_SIMPLEX, .6, text_color, 1, cv2.LINE_AA)



        if show_preview:
            cv2.imshow("output", preview) # numpy.hstack([image, output]))
            cv2.waitKey(0)
            # time.sleep(0)

    rc, jpeg_pic = cv2.imencode(".jpg", preview)
    ret_pic = jpeg_pic.tobytes()

    return ret, ret_pic


last_data = {}
last_pic = None

@app.route("/")
def index():
    doc, tag, text = Doc().tagtext()

    with tag('h2'):
        text("Get Data Area")

    with tag('form', ('method', 'get'), ('action','/get')):
        with tag('big'):
            with tag('table'):
                with tag('tr'):
                    with tag('td'):
                        text("dp")
                        with tag('input', ('type', 'text'), ('name', 'dp'), ('value', 1.4)):
                            pass
                    with tag('td'):
                        text("minDist")
                        with tag('input', ('type', 'text'), ('name', 'minDist'), ('value', 16)):
                            pass
                    with tag('td'):
                        text("minRad")
                        with tag('input', ('type', 'text'), ('name', 'minRad'), ('value', 64)):
                            pass
                    with tag('td'):
                        text("maxRad")
                        with tag('input', ('type', 'text'), ('name', 'maxRad'), ('value', 2)):
                            pass

                with tag('tr'):
                    with tag('td'):
                        with tag('input', ('type', 'submit'), ('name', 'mode'), ('value', 'get fresh analysis')):
                            pass

                    with tag('td'):
                        text("width")
                        with tag('input', ('type', 'text'), ('name', 'width'), ('value', 1024)):
                            pass
                    with tag('td'):
                        text("height")
                        with tag('input', ('type', 'text'), ('name', 'height'), ('value', 768)):
                            pass

                    with tag('td'):
                        with tag('a', ('href', 'https://docs.opencv.org/2.4/modules/imgproc/doc/feature_detection.html?highlight=houghcircles#houghcircles')):
                            text('doc: HoughCircles documentation')
                        text(" | ")
                        with tag('a', ('href', 'http://gitlab.gebaschtel.ch/Elektronik/AutoLunaObs/blob/master/Raspi/6663-OcvService.py#L50')):
                            text('doc: function call itself')


    with tag('hr'):
        pass
    with tag('h2'):
        text("last data")
    with tag('pre'):
        text(json.dumps(last_data, indent=True))

    with tag('hr'):
        pass
    with tag('h2'):
        text("last pic")
    with tag('img', ('src','/last.jpeg')):
        pass

    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')

@app.route("/get")
def get_get(width=3280, height=2464, dp=1.4, minDist=16, minRad=64, maxRad=2):
    global last_data, last_pic

    if 'width' in request.args:  width = int(request.args['width'])
    if 'height' in request.args:  height = int(request.args['height'])
    if 'dp' in request.args:  dp = float(request.args['dp'])
    if 'minDist' in request.args:  minDist = float(request.args['minDist'])
    if 'minRad' in request.args:  minRad = float(request.args['minRad'])
    if 'maxRad' in request.args:  maxRad = float(request.args['maxRad'])

    url = "http://127.0.0.1:6660/pic.jpeg?w=" + str(width) + "&h=" + str(height)

    data, pic = from_pic_get_circles(url=url,show_preview=True, dp=dp, minDist=minDist, minRad=minRad, maxRad=maxRad)

    data['last_jpeg'] = 'http://' + request.environ['HTTP_HOST'] + '/last.jpeg'
    data['last_json'] = 'http://' + request.environ['HTTP_HOST'] + '/last.json'
    data['pic_src'] = url

    last_data = data
    last_pic = pic
    return redirect("/", code=302)
    #return redirect(data['last_json'], code=302)
    #return Response(json.dumps(data, indent=True), mimetype='text/json;charset=UTF-8')

@app.route("/last.jpeg")
def get_pic():
    return Response(last_pic, mimetype="image/jpeg")

@app.route("/last.json")
def get_data():
    return Response(json.dumps(last_data, indent=True), mimetype='text/json;charset=UTF-8')

if __name__ == '__main__':
    logging.info("starting flask")
    app.run(host='0.0.0.0', port=6661, debug=False)

