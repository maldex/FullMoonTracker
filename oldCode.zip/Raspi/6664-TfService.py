#!/usr/bin/env python3
# -*- coding: utf-8 -*-
port = 6664
desc = """ 6664-TfMotorService
"""

import logging, threading, time, os
import simplejson as json
from flask import Flask, request, Response
from yattag import Doc


from tinkerforge.ip_connection import IPConnection
from tinkerforge.brick_silent_stepper import BrickSilentStepper
import threading

horizontalUID = "6mV328"
verticalUID = "6sQeeJ"


logging.basicConfig(level=logging.DEBUG, format='%(name)s:%(levelname)s:%(message)s')



class TF_motor():
    def __init__(self, ipcon, uid):
        self._ipcon, self.uid = ipcon, uid

        self._ss = BrickSilentStepper(self.uid, self._ipcon)
        self._ss.set_motor_current(800)  # 800mA
        self._ss.set_step_configuration(self._ss.STEP_RESOLUTION_32, True)  # 1/8 steps (interpolated)

        # Slow acceleration (500 steps/s^2),
        # Fast deacceleration (5000 steps/s^2)
        self._ss.set_speed_ramping(0, 0)
        self._ss.enable()  # enable motor power


    def __del__(self):
        try:
            self._ss.disable()
        except Exception as e:
            pass

    def drive(self, steps, velocity=5000):
        self._ss.set_max_velocity(velocity)  # Velocity 2000 steps/s
        self._ss.set_steps(steps)  # Drive 60000 steps forward

    def get_remaining(self):
        return self._ss.get_remaining_steps()


###
# helper Stuff
###
def synchronized_method(method):
    """simple way of locking annotated method calls within different threads"""
    outer_lock = threading.Lock()
    lock_name = "__" + method.__name__ + "_lock" + "__"

    def sync_method(self, *args, **kws):
        with outer_lock:
            if not hasattr(self, lock_name): setattr(self, lock_name, threading.Lock())
            lock = getattr(self, lock_name)
            with lock:
                return method(self, *args, **kws)

    return sync_method


class GetSetConfigDataWorkerThread(threading.Thread):
    """simplified async worker thread that provides data and reads config"""

    def __init__(self, _call_debug=False):
        threading.Thread.__init__(self)
        self._data = {}
        self._alive = True
        self._logger = logging.getLogger(f"{self.__class__.__name__}-{hex(id(self))}".lower())
        self._call_debug = _call_debug
        if self._call_debug: self._logger.debug(
            f"({threading.currentThread().getName()}) class {self} initializing at {hex(id(self))}")

    @synchronized_method
    def _get_aliveness(self):
        return self._alive

    @synchronized_method
    def stop(self):
        if self._call_debug: self._logger.debug(f"({threading.currentThread().getName()}) class {self} stopping at {hex(id(self))}")
        self._alive = False

    @synchronized_method
    def set_data(self, data, timestamp=True):
        if timestamp:  data['timestamp'] = round(time.time(), 2)
        # self._data = data
        self._data.update(data)
        # if self._call_debug: self._logger.debug(f"({threading.currentThread().getName()}) _call_debug: set_data({data})")

    @synchronized_method
    def get_data(self):
        #if self._call_debug: self._logger.debug(f"({threading.currentThread().getName()}) _call_debug: get_data() -> {self._data}")
        return self._data  # copy.deepcopy

    @synchronized_method
    def set_config(self, config):
        if self._call_debug: self._logger.debug(f"({threading.currentThread().getName()}) _call_debug: set_config({config})")
        self.__dict__.update(config)

    @synchronized_method
    def get_config(self):
        r = {k: v for k, v in self.__dict__.items() if not k.startswith('_')}  # remove attributes staring with '_'
        # if self._call_debug: self._logger.debug(f"({threading.currentThread().getName()}) _call_debug: get_config() -> {r}")
        return r


###                                                                 ###
# here we go descriping the async thread doing the hard working stuff #
###                                                                 ###
###                                                                 ###
#                   !!!THIS IS OUR CLASS TO ADJUST!!!               #
###                                                                 ###

class MyThing(GetSetConfigDataWorkerThread):
    """sample of worker task / thread, 'run' implements the main in the thread, config/data setter and getter are derived from parent"""

    def __init__(self, poll_interval=0.1, velocity=1000):
        super().__init__(_call_debug=True)
        self.name = "WorkerThread"

        # class-specific code
        self.set_config({'poll_interval': poll_interval, 'velocity': velocity})
        self.set_data({'h_steps':0, 'v_steps':0 })
        self._last_steps_h = 0; self._last_steps_v = 0

        ipcon = IPConnection()
        ipcon.connect("127.0.0.1", 4223)

        self._motor_horizontal = TF_motor(ipcon, "6mV328")
        self._motor_vertical = TF_motor(ipcon,"6sQeeJ")

        self._logger.info(f"({threading.currentThread().getName()}) hello world")



    def run(self):  # entrypoint for thread
        self._logger.info(F"({threading.currentThread().getName()}) entering thread")
        while self._get_aliveness():  # this is the main-loop of this thread
            self.every_once_and_then_actually_calc_data()
            time.sleep(self.poll_interval)
        self._logger.info(F"({threading.currentThread().getName()}) leaving thread")

    def every_once_and_then_actually_calc_data(self):
        data = self.get_data()
        if (data['h_steps'] > 0 and data['h_steps'] > self._last_steps_h) or \
           (data['h_steps'] < 0 and data['h_steps'] < self._last_steps_h):
           self._motor_horizontal.drive(data['h_steps'], velocity=self.velocity)
        if (data['v_steps'] > 0 and data['v_steps'] > self._last_steps_v) or \
           (data['v_steps'] < 0 and data['v_steps'] < self._last_steps_v):
           self._motor_vertical.drive(data['v_steps'], velocity=self.velocity)

        data['h_steps'] = self._motor_horizontal.get_remaining()
        data['v_steps'] = self._motor_vertical.get_remaining()
        self._last_steps_h = data['h_steps'] ; self._last_steps_v = data['v_steps']

        self.set_data(data)
        return data


###
# flask related code starts here
###
app = Flask(__name__, static_url_path='')
app.logger.setLevel(logging.DEBUG)


@app.route("/data", methods=['GET', 'POST'])
def flask_handle_data():
    if request.environ['REQUEST_METHOD'] == 'POST':
        rq_payload = request.get_json(force=True)
        logging.info(f"updating data with {rq_payload}")
        MyInstance.set_data(rq_payload)
    return Response(json.dumps(MyInstance.get_data(), indent=True), mimetype='text/json;charset=UTF-8')


@app.route("/config", methods=['GET', 'POST'])
def flask_handle_config():  # TODO: review, i think merging the arrtibutes is done in set_config()
    if request.environ['REQUEST_METHOD'] == 'POST':
        rq_payload = request.get_json(force=True)
        logging.info(f"updating config with {rq_payload}")
        MyInstance.set_config(rq_payload)
    return Response(json.dumps(MyInstance.get_config(), indent=True), mimetype='text/json;charset=UTF-8')


@app.route("/", methods=['GET', 'POST'])
def flask_handle_index():
    doc, tag, text = Doc().tagtext()
    with tag('h3'):
        text('welcome to API to ' + str(MyInstance))
    with tag('a', ('href', '/data')):
        text('data')
    text(" | ")
    with tag('a', ('href', '/config')):
        text('config')
    text(" | ")
    with tag('a', ('href', '/admin')):
        text('admin')
    with tag('pre'):
        text(desc)
    with tag('hr'): pass
    with tag('h3'):
        text('usage')
    with tag('pre'):
        text("wget -qO - http://" + request.environ['HTTP_HOST'] + "/data" + os.linesep)
        text("wget -qO - --post-data '" + json.dumps(MyInstance.get_data()) + "' http://" + request.environ['HTTP_HOST'] + "/data"  + os.linesep)
        text("wget -qO - http://" + request.environ['HTTP_HOST'] + "/config" + os.linesep)
        text("wget -qO - --post-data '" + json.dumps(MyInstance.get_config()) + "' http://" + request.environ['HTTP_HOST'] + "/config" + os.linesep)
    with tag('hr'): pass
    with tag('h3'):
        text('flask registered endpoints')
    with tag('pre'):
        for x in (list(map(lambda x: repr(x), app.url_map.iter_rules()))):
            text(x + os.linesep)
    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')


@app.route("/admin", methods=['GET', 'POST'])
def flask_handle_admin():
    doc, tag, text = Doc().tagtext()
    with tag('a', ('href', '/')):
        text('home')
    try:  # not nice, but i think these functions should maybe not exist at all
        if request.form.to_dict(flat=True)['mode'] == 'KILLWORKER':
            logging.warning("KILLWORKER")
            MyInstance.stop()
        if request.form.to_dict(flat=True)['mode'] == 'FLASKEXIT':
            logging.warning("FLASKEXIT")
            func = request.environ.get('werkzeug.server.shutdown')
            func()
        if request.form.to_dict(flat=True)['mode'] == 'SYSEXIT':
            logging.warning("SYSEXIT")
            os._exit(222)
        return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')
    except KeyError:
        pass  # no button was pressed

    with tag('h3'):
        text('admin area')
    text("not sure this very function should be exposed ... " + str(time.time()))
    with tag('form', ('method', 'post')):
        with tag('button', ('type', 'submit'), ('name', 'mode'), ('value', 'KILLWORKER')):
            text("stop worker thread")
        with tag('button', ('type', 'submit'), ('name', 'mode'), ('value', 'FLASKEXIT')):
            text("terminate flask")
        with tag('button', ('type', 'submit'), ('name', 'mode'), ('value', 'SYSEXIT')):
            text("terminate python")
    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')


def watchdog(instance):
    assert isinstance(instance, MyThing)
    time.sleep(0.1)
    while (time.time() - instance.get_data()['timestamp'] <= instance.poll_interval * 2):
        time.sleep(instance.poll_interval / 2)

    logging.fatal(f"({threading.currentThread().getName()}) exiting b/stale data: set_data({instance.get_data()})")
    try:   instance.stop()
    except Exception as e: pass
    os._exit(221)


###
# the main method
###
if __name__ == '__main__':
    logging.info(f"__main__ instantiate MyThing")
    MyInstance = MyThing()
    logging.info(f"__main__ starting staring '{MyInstance.__class__.__name__}'")
    MyInstance.start()

    logging.info(f"__main__ starting watchdog for " + str(MyInstance))
    threading.Thread(target=watchdog, args=(MyInstance,), name="WatchDog").start()

    logging.info(f"__main__ starting flask {app}")

    app.run(host='0.0.0.0', port=port, debug=False)  # blocking

    logging.warning(f"__main__ flask stopped")

    logging.info(f"__main__ stopping thread for '{MyInstance.__class__.__name__}'")
    MyInstance.stop()
    logging.info(f"__main__ byebye")
