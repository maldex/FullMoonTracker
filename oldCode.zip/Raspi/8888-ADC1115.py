#!/usr/bin/env python3
# -*- coding: utf-8 -*-
desc = """ 8888-ADC1115
    sudo apt-get install build-essential python-dev python-smbus python-pip
    sudo pip install adafruit-ads1x15
"""
import logging, threading, time, os
import simplejson as json
from flask import Flask, request, Response
from yattag import Doc

logging.basicConfig(level=logging.DEBUG, format='%(name)s:%(levelname)s:%(message)s')

import Adafruit_ADS1x15
logging.getLogger("Adafruit_I2C.Device").setLevel(logging.INFO)

class MyADS1115():
    def __init__(self, gain=1):
        self.gain = gain
        self.adc = Adafruit_ADS1x15.ADS1115()

    def read(self):
        return 0

    def crap(self):
        return {"ADC0": self.adc.read_adc(0, gain=self.gain),
                "ADC1": self.adc.read_adc(1, gain=self.gain),
                "ADC2": self.adc.read_adc(2, gain=self.gain),
                "ADC3": self.adc.read_adc(3, gain=self.gain)}

###
# helper Stuff
###
def synchronized_method(method):
    """simple way of locking annotated method calls within different threads"""
    outer_lock = threading.Lock()
    lock_name = "__" + method.__name__ + "_lock" + "__"
    def sync_method(self, *args, **kws):
        with outer_lock:
            if not hasattr(self, lock_name): setattr(self, lock_name, threading.Lock())
            lock = getattr(self, lock_name)
            with lock:
                return method(self, *args, **kws)
    return sync_method


class GetSetConfigDataWorkerThread(threading.Thread):
    """simplified async worker thread that provides data and reads config"""
    def __init__(self, _call_debug=False):
        threading.Thread.__init__(self)
        self._alive = True
        self.set_data({"initializing": "no data yet"})
        self._logger = logging.getLogger(f"{self.__class__.__name__}-{hex(id(self))}".lower())
        self._call_debug = _call_debug
        if self._call_debug: self._logger.debug(f"({threading.get_ident()}) class {self} initializing at {hex(id(self))}")

    @synchronized_method
    def _get_aliveness(self):
        return self._alive

    @synchronized_method
    def stop(self):
        if self._call_debug: self._logger.debug(f"({threading.get_ident()}) class {self} stopping at {hex(id(self))}")
        self._alive = False

    @synchronized_method
    def set_data(self, data, timestamp=True):
        if timestamp:  data['timestamp'] = round(time.time(),2)
        self._data = data
        #if self._call_debug: self._logger.debug(f"({threading.get_ident()}) _call_debug: set_data({data})")

    @synchronized_method
    def get_data(self):
        if self._call_debug: self._logger.debug(f"({threading.get_ident()}) _call_debug: get_data() -> {self._data}")
        return self._data   # copy.deepcopy

    @synchronized_method
    def set_config(self, config):
        if self._call_debug: self._logger.debug(f"({threading.get_ident()}) _call_debug: set_config({config})")
        self.__dict__.update(config)

    @synchronized_method
    def get_config(self):
        r = {k: v for k, v in self.__dict__.items() if not k.startswith('_')} # remove attributes staring with '_'
        #if self._call_debug: self._logger.debug(f"({threading.get_ident()}) _call_debug: get_config() -> {r}")
        return r



###                                                                 ###
# here we go descriping the async thread doing the hard working stuff #
###                                                                 ###
class MyThing(GetSetConfigDataWorkerThread):
    """sample of worker task / thread, 'run' implements the main in the thread, config/data setter and getter are derived from parent"""
    def __init__(self, poll_interval=1.0, addr=0x48, gain=1):
        super().__init__(_call_debug=False)
        self.poll_interval, self.addr, self.gain = poll_interval, addr, gain
        self._adc = Adafruit_ADS1x15.ADS1115(self.addr)
        self._logger.info(f"({threading.get_ident()}) hello world")

    def run(self): # entrypoint for thread
        self._logger.info(F"({threading.get_ident()}) entering thread")
        while self._get_aliveness():            # this is the main-loop of this thread
            data = self.every_once_and_then_actually_calc_data()
            self.set_data(data)
            time.sleep(self.poll_interval)
        self._logger.info(F"({threading.get_ident()}) leaving thread")

    def every_once_and_then_actually_calc_data(self):
        data = { "ADC0": self._adc.read_adc(0, gain=self.gain),
                 "ADC1": self._adc.read_adc(1, gain=self.gain),
                 "ADC2": self._adc.read_adc(2, gain=self.gain),
                 "ADC3": self._adc.read_adc(3, gain=self.gain),
                 "config": self.get_config()}
        return data




###
# flask related code starts here
###
app = Flask(__name__, static_url_path='')
app.logger.setLevel(logging.DEBUG)

@app.route("/data",  methods=['GET'])
def flask_handle_data():
    data = MyInstance.get_data()
    return Response(json.dumps(data, indent=True), mimetype='text/json;charset=UTF-8')


@app.route("/config",  methods=['GET', 'POST'])
def flask_handle_config():    # TODO: review, i think merging the arrtibutes is done in set_config()
    rq_data = {}
    for k, v in request.args.items():
        rq_data[k] = v

    if request.environ['REQUEST_METHOD'] == 'POST':
        rq_data.update(request.get_json())

    config = MyInstance.get_config()
    if rq_data: # not empty
        logging.info(f"updating config with {rq_data}")
        config.update(rq_data)
        MyInstance.set_config(rq_data)

    return Response(json.dumps(config, indent=True), mimetype='text/json;charset=UTF-8')



@app.route("/", methods=['GET', 'POST'])
def flask_handle_index():
    doc, tag, text = Doc().tagtext()
    with tag('h3'):
        text('welcome to API to ' + str(MyInstance))
    with tag('a', ('href', '/playground')):
        text('playground')
    text(" | ")
    with tag('a', ('href', '/data')):
        text('data')
    text(" | ")
    with tag('a', ('href', '/config')):
        text('config')
    text(" | ")
    with tag('a', ('href', '/admin')):
        text('admin')
    with tag('pre'):
        text("""curl -XPOST -H "Content-Type: application/json" 'http://""" + request.environ['HTTP_HOST'] + """?new=hi' -d '{"counter":-1000, "increment":2}'""" + os.linesep)
        text("""wget -O- --header='Content-Type:application/json' --post-data='{"counter":-4000, "increment":4}' 'http://""" + request.environ['HTTP_HOST'] + """?new=hi'""" + os.linesep)
    with tag('hr'): pass
    with tag('h3'):
        text('flask registered endpoints')
    with tag('pre'):
        for x in (list(map(lambda x: repr(x), app.url_map.iter_rules()))):
            text(x + os.linesep)
    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')



@app.route("/admin", methods=['GET', 'POST'])
def flask_handle_admin():
    doc, tag, text = Doc().tagtext()
    with tag('a', ('href', '/')):
        text('home')
    try:  # not nice, but i think these functions should maybe not exist at all
        if request.form.to_dict(flat=True)['mode'] == 'KILLWORKER':
            logging.warning("KILLWORKER")
            MyInstance.stop()
        if request.form.to_dict(flat=True)['mode'] == 'FLASKEXIT':
            logging.warning("FLASKEXIT")
            func = request.environ.get('werkzeug.server.shutdown')
            func()
        if request.form.to_dict(flat=True)['mode'] == 'SYSEXIT':
            logging.warning("SYSEXIT")
            os._exit(222)
        return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')
    except KeyError:
        pass # no button was pressed

    with tag('h3'):
        text('admin area')
    text("not sure this very function should be exposed ... " + str(time.time()))
    with tag('form', ('method', 'post')):
        with tag('button', ('type', 'submit'), ('name', 'mode'), ('value', 'KILLWORKER')):
            text("stop worker thread")
        with tag('button', ('type', 'submit'), ('name', 'mode'), ('value', 'FLASKEXIT')):
            text("terminate flask")
        with tag('button', ('type', 'submit'), ('name', 'mode'), ('value', 'SYSEXIT')):
            text("terminate python")
    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')



@app.route("/playground", methods=['GET', 'POST'])
def flask_handle_playground():
    doc, tag, text = Doc().tagtext()
    rq_data = {}
    with tag('h2'):
        text("request.args")
    with tag('pre'):
        for k,v in request.args.items():
            rq_data[k] = v
            doc.asis(str(k) + ': ' + str(v) + os.linesep)
    with tag('hr'):     pass
    with tag('h2'):
        text("request.environ")
    with tag('pre'):
        for k, v in request.environ.items():
            doc.asis(str(k) + ': ' + str(v) +os.linesep)
    with tag('hr'):     pass
    with tag('h2'):
        text("request.data")
    if request.environ['REQUEST_METHOD'] == 'POST':
        with tag('pre'):
            try:
                for k, v in request.get_json().items():
                    doc.asis(str(k) + ': ' + str(v) + os.linesep)
            except AttributeError:
                try:
                    doc.asis(str('request.get') + ': ' + str(request.form.to_dict(flat=True)) + os.linesep)
                except AttributeError:
                    doc.asis("not sure how to handle request-data in POST mode")
    else:
        text("request of type '" + request.environ['REQUEST_METHOD'] + "' not handle")
    with tag('hr'):    pass
    with tag('h2'):
        text("data")
    with tag('pre'):
        for k, v in rq_data.items():
            doc.asis(str(k) + ': ' + str(v) + os.linesep)
        # text(str(type(request.get_json())))  # request.get_json()
    return Response(doc.getvalue(), mimetype='text/html;charset=UTF-8')



###
# the main method
###
if __name__ == '__main__':
    logging.info(f"__main__ instantiate MyThing")
    MyInstance = MyThing()
    logging.info(f"__main__ starting staring '{MyInstance.__class__.__name__}'")
    MyInstance.start()

    logging.info(f"__main__ starting flask {app}")

    app.run(host='0.0.0.0', port=8888, debug=False) # blocking

    logging.warning(f"__main__ flask stopped")

    logging.info(f"__main__ stopping thread for '{MyInstance.__class__.__name__}")
    MyInstance.stop()
    logging.info(f"__main__ byebye")
