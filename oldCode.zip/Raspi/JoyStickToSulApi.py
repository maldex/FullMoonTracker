#!/usr/bin/env python3

import pygame
from time import sleep
from urllib.request import Request, urlopen  # Python 3

sul_api_url = "http://10.83.6.200/api/"

sul_api_speed = 2000
sul_api_steps = 1000



pygame.init()

joysticks = []
while len(joysticks)==0 :
	sleep(0.3)
	joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

print(joysticks)
#j = pygame.joystick.Joystick(0)
j=joysticks[0]
j.init()
print('get_init(): %s', joysticks)
print('Initialized Joystick : %s' % j.get_name())



d = j.get_numaxes()
while 1:
	pygame.event.pump()
	axes  = [ j.get_axis(i) for i in range(0,j.get_numaxes()) ]
	balls = [ j.get_ball(i) for i in range(0,j.get_numballs()) ]
	hats  = [ j.get_hat(i) for i in range(0,j.get_numhats()) ]
	buttons = [ j.get_button(i) for i in range(0,j.get_numbuttons()) ]
	print(axes,balls,hats,buttons)

	x_url = sul_api_url + "x/" + str(sul_api_speed) + "/" + str(int(sul_api_steps * axes[0] ))
	y_url = sul_api_url + "y/" + str(sul_api_speed) + "/" + str(int(sul_api_steps * axes[1] * -1))

	try:
		print(x_url)
		print("X: " + str( urlopen(x_url, timeout=1).read()))
	except Exception:
		pass
	try:
		print(y_url)
		print("Y: " + str( urlopen(y_url, timeout=1).read()))
	except Exception:
		pass
	print("--------------------------------------------------------------------")
	# sleep(0.1)
