#!/usr/bin/env python3

import pygame
from time import sleep


pygame.init()

joysticks = []
while len(joysticks)==0 :
	sleep(0.3)
	joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

print(joysticks)
#j = pygame.joystick.Joystick(0)
j=joysticks[0]
j.init()
print('get_init(): %s', joysticks)
print('Initialized Joystick : %s' % j.get_name())



d = j.get_numaxes()
while 1:
	pygame.event.pump()
	axes  = [ j.get_axis(i) for i in range(0,j.get_numaxes()) ]
	balls = [ j.get_ball(i) for i in range(0,j.get_numballs()) ]
	hats  = [ j.get_hat(i) for i in range(0,j.get_numhats()) ]
	buttons = [ j.get_button(i) for i in range(0,j.get_numbuttons()) ]

	# sanitize joystick axis
	for i in range(0, len(axes)):
		axes[i] = round(axes[i], 3)
		if (axes[i] > 0.0 and (axes[i] < 0.1 or axes[i] > 1.0)) or \
		   (axes[i] < 0.0 and (axes[i] > -0.1 or axes[i] < -1.0)):
			axes[i] = 0.0

	print(axes,balls,hats,buttons)
	#print("--------------------------------------------------------------------")
	sleep(0.1)
