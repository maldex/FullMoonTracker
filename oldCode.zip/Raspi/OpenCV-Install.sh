#!/bin/bash
#https://www.learnopencv.com/install-opencv-4-on-raspberry-pi/
set -x
set -e 

cd /usr/local/src

cvVersion="4.1.1"

function install_protobuf(){
    # https://github.com/EdjeElectronics/TensorFlow-Object-Detection-on-the-Raspberry-Pi#4-compile-and-install-protobuf
    sudo apt-get -y install autoconf automake libtool curl
    cd /usr/local/src
    wget -q -O - https://github.com/google/protobuf/releases/download/v3.10.0/protobuf-all-3.10.0.tar.gz | tar -zxf -
    cd protobuf-3.*/
    time ./configure --enable-static --with-zlib
    time make -j$(nproc)
    # time make check
    sudo make install
    cd python
    export LD_LIBRARY_PATH=../src/.libs
    python3 setup.py build --cpp_implementation 
    #python3 setup.py test --cpp_implementation
    sudo python3 setup.py install --cpp_implementation
    export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=cpp
    export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION_VERSION=3
    sudo ldconfig
}

function fix_packages() {
    sudo sed -i 's/CONF_SWAPSIZE=.*/CONF_SWAPSIZE=2048/g' /etc/dphys-swapfile
    sudo /etc/init.d/dphys-swapfile restart

    sudo apt-get -y purge wolfram-engine
    sudo apt-get -y purge libreoffice*
    sudo apt-get -y clean
    sudo apt-get -y autoremove

    sudo apt -y update

    sudo apt-get -y remove x264 libx264-dev
     
    ## Install dependencies
    sudo apt-get -y install build-essential checkinstall cmake pkg-config yasm
    sudo apt-get -y install git gfortran
    sudo apt-get -y install libjpeg8-dev libjasper-dev libpng12-dev
     
    sudo apt-get -y install libtiff5-dev
     
    sudo apt-get -y install libtiff-dev
     
    sudo apt-get -y install libavcodec-dev libavformat-dev libswscale-dev libdc1394-22-dev
    sudo apt-get -y install libxine2-dev libv4l-dev
    cd /usr/include/linux
    sudo ln -s -f ../libv4l1-videodev.h videodev.h
    cd $cwd
     
    sudo apt-get -y install libgstreamer0.10-dev libgstreamer-plugins-base0.10-dev
    sudo apt-get -y install libgtk2.0-dev libtbb-dev qt5-default
    sudo apt-get -y install libatlas-base-dev
    sudo apt-get -y install libmp3lame-dev libtheora-dev
    sudo apt-get -y install libvorbis-dev libxvidcore-dev libx264-dev
    sudo apt-get -y install libopencore-amrnb-dev libopencore-amrwb-dev
    sudo apt-get -y install libavresample-dev
    sudo apt-get -y install x264 v4l-utils
     
    # Optional dependencies
    # sudo apt-get -y remove libprotobuf-dev protobuf-compiler libprotoc-dev libprotobuf-c-dev python3-protobuf
    sudo apt-get -y install libgoogle-glog-dev libgflags-dev
    sudo apt-get -y install libgphoto2-dev libeigen3-dev libhdf5-dev doxygen
    
    sudo apt-get -y install python3-dev python3-pip
    sudo -H pip3 install -U pip numpy dlib
    sudo apt-get -y install python3-testresources

    sudo apt-get -y install libglu1-mesa-dev freeglut3-dev 
    sudo apt-get -y install libceres-dev libtesseract-dev libtesseract4 libjemalloc-dev libjemalloc2
    sudo apt-get -y install eigensoft libeigen2-dev libeigen3-dev liblapack-dev liblapacke-dev libgstreamermm-1.0-dev doxygen libcaffe-cpu-dev golang-glog-dev gstreamer0.10-plugins-base-apps gstreamer1.0-dev gstreamer1.0-tools
 
    sudo pip3 install numpy dlib
    # quit virtual environment
    #deactivate
    sudo ln -s /usr/include/eigen3/Eigen /usr/include/Eigen
}

if [ ! -e /usr/bin/gst-launch-1.0 ]; then
    fix_packages   
    fi

if [ ! -e /usr/local/src/protobuf-3.10.0 ]; then
    time install_protobuf  
    fi

# rm -rf opencv opencv_contrib

if [ ! -e opencv ]; then
time git clone --branch "$cvVersion" https://github.com/opencv/opencv.git
fi
#cd opencv
#git checkout $cvVersion
#cd ..
 
if [ ! -e opencv_contrib ]; then
time git clone --branch "$cvVersion" https://github.com/opencv/opencv_contrib.git
fi
#cd opencv_contrib
#git checkout $cvVersion
#cd ..

# Clean build directories
rm -rf opencv/build
rm -rf opencv_contrib/build

# get started in build/
cd opencv
if [ ! -e build ]; then mkdir build; fi
cd build
                  
time cmake -DCMAKE_CXX_FLAGS=-std=c++11 -DENABLE_CXX11=ON -DCMAKE_BUILD_TYPE=RELEASE \
            -DPYTHON_EXECUTABLE=`which python3` \
            -DOPENCV_EXTRA_MODULES_PATH=../../opencv_contrib/modules \
            -DOPENCV_ENABLE_NONFREE=ON \
            -DCMAKE_INSTALL_PREFIX=/usr/local \
            -DINSTALL_C_EXAMPLES=OFF \
            -DINSTALL_PYTHON_EXAMPLES=OFF \
            -DBUILD_DOCS=ON \
            -DBUILD_EXAMPLES=OFF \
            -DBUILD_SHARED_LIBS=OFF \
            -DBUILD_PERF_TESTS=OFF \
            -DBUILD_TESTS=OFF \
            -DBUILD_PROTOBUF=OFF \
            -DWITH_PROTOBUF=ON \
            ../

echo "--- $?"
sleep 10
#read -t 60  -p "Hit ENTER or wait "
time make -j$(nproc)
echo "--- $?"
echo "run 'make install'  manually in `pwd`"

exit 0

time cmake -D CMAKE_CXX_FLAGS=-std=c++11 -D ENABLE_CXX11=ON -D CMAKE_BUILD_TYPE=RELEASE \
            -D CMAKE_INSTALL_PREFIX=/usr/local \
            -D INSTALL_C_EXAMPLES=OFF \
            -D INSTALL_PYTHON_EXAMPLES=ON \
            -D WITH_TBB=ON \
            -D WITH_V4L=ON \
            -D WITH_QT=ON \
            -D WITH_OPENGL=ON \
            -D WITH_JPEG=ON \
            -D WITH_FFMPEG=ON \
            -D WITH_GSTREAMER=ON \
            -D WITH_OPENMP=ON \
            -D WITH_OPENCL=ON \
            -D WITH_GPHOTO2=ON \
            -D WITH_LIBV4L=ON \
            -D BUILD_SHARED_LIBS=OFF \
            -D BUILD_PERF_TESTS=OFF \
            -D BUILD_TESTS=OFF \
            -D ENABLE_PRECOMPILED_HEADERS=OFF \
            -D OPENCV_PYTHON2_INSTALL_PATH=/usr/local/lib/python2.7/dist-packages \
            -D OPENCV_PYTHON3_INSTALL_PATH=/usr/local/lib/python3.7/dist-packages \
            -D PYTHON3_EXECUTABLE=`which python3` \
            -D PYTHON2_EXECUTABLE=`which python2` \
            -D PYTHON_EXECUTABLE=`which python3` \
            -D OPENCV_EXTRA_MODULES_PATH=../../opencv_contrib/modules \
            -D BUILD_EXAMPLES=OFF ../
