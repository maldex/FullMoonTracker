#!/usr/bin/python3
# -*- coding: utf-8 -*-


import cv2
import numpy
import time
import urllib
import simplejson as json
from datetime import datetime
from urllib.request import Request, urlopen  # Python 3
from pprint import pprint
from time import sleep
from flask import Flask, request, Response, render_template, send_from_directory, send_file, abort, redirect
from yattag import Doc
import logging, os
import urllib.error
import simplejson as json
from copy import deepcopy
linesep = os.linesep

app = Flask(__name__, static_url_path='')
app.logger.setLevel(logging.DEBUG)
logging.basicConfig(level=logging.DEBUG)

def from_pic_get_circles(image, show_preview=True, dp=1.5, minDist=16, minRad=64, maxRad=10):
    # resp = urlopen(url)
    # image = numpy.asarray(bytearray(resp.read()), dtype="uint8")
    # image = cv2.imdecode(image, cv2.IMREAD_COLOR)

    preview = image.copy()


    other_color = (160, 160, 255)
    disp_color = (32, 64, 192)
    text_color = (32, 255, 32)

    cv2.line(preview, (0, int(image.shape[0] / 2)), (image.shape[1], int(image.shape[0] / 2)), (0, 0, 0), 1)
    cv2.line(preview, (int(image.shape[1] / 2), 0), (int(image.shape[1] / 2), image.shape[0]), (0, 0, 0), 1)

    c={
        "dp": dp,
        "minDist_divider": minDist,
        "minRadius_divider": minRad,
        "maxRadius_divider": maxRad
    }

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # detect circles in the image
    stime = time.time()
    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=c['dp'], minDist=int(image.shape[0]/c['minDist_divider']), minRadius=int(image.shape[0]/c['minRadius_divider']), maxRadius=int(image.shape[0]/c['maxRadius_divider']))
    delta = int((time.time() - stime) * 1000 * 1000 ) / 1000

    ret = {
        "config": c,
        "metric": {"picture_size": [image.shape[1], image.shape[0]],
                   "processing_ms": delta,
                   "circles_found": None
                   },
        "circles": []
    }


    if circles is not None:
        ret['metric']['circles_found'] = len(circles)
        circles = numpy.round(circles[0, :]).astype("int")

        print("found " + str(len(circles)) + " circles in " + str(delta))

        biggest_one = (0,0,0)
        dX, dY = None, None

        # loop over the (x, y) coordinates and radius of the circles
        for (x, y, r) in circles:
            # draw the circle in the output image, then draw a rectangle
            # corresponding to the center of the circle
            print("circle at " + str((x,y,r)))
            cir = (x,y,r)
            ret['circles'].append((int(x), int(y), int(r)))

            # cv2.rectangle(output, (x - 5, y - 5), (x + 5, y + 5), (0, 128, 255), -1)

            # cv2.rectangle(preview, (x - r, y - r), (x + r, y + r), disp_color, 1)


            cv2.line(preview, (x - 5, y - 5), (x + 5, y + 5), other_color, 1)
            cv2.line(preview, (x - 5, y + 5), (x + 5, y - 5), other_color, 1)

            cv2.circle(preview, (x, y), r, other_color, 1)


            dX = -int(image.shape[1]/2 - x )
            dY = -int(image.shape[0]/2 - y )
            text = str("X:" + str(x) + ", Y:" + str(y) + ", R:" + str(r))
            cv2.putText(preview, text, (x, y+3), cv2.FONT_HERSHEY_SIMPLEX, .3, other_color, 1, cv2.LINE_AA)
            # text = "dX:" + str(dX) + " dY:" + str(dY)
            # cv2.putText(preview, text, (x, y + 12), cv2.FONT_HERSHEY_SIMPLEX, .3, other_color, 1, cv2.LINE_AA)

            if biggest_one[2] < r:
                biggest_one = (x, y, r, dX, dY)


        ret['biggest'] = { "x": int(biggest_one[0]),
                         "y": int(biggest_one[1]),
                         "r": int(biggest_one[2]),
                         "dX": int(biggest_one[3]), "dY": int(biggest_one[4]) }


        x,y,r,dX,dY = biggest_one
        l = 15
        # cv2.line(preview, (x + r, y + r), (x + r - l, y + r - l), text_color, 2)
        cv2.line(preview, (x - r, y + r), (x, y + r), text_color, 2)
        cv2.line(preview, (x - r, y + r), (x - r, y), text_color, 2)
        # cv2.line(preview, (x - r, y - r), (x - r + l, y - r + l), text_color, 2)
        cv2.line(preview, (x + r, y - r), (x, y - r), text_color, 2)
        cv2.line(preview, (x + r, y - r), (x + r, y), text_color, 2)

        cv2.line(preview, (x - l, y - l), (x + l, y + l), text_color, 2)
        cv2.line(preview, (x - l, y + l), (x + l, y - l), text_color, 2)

        text = str("X:" + str(x) + ", Y:" + str(y) + ", R:" + str(r))
        cv2.putText(preview, text, (x-r, y+r-l), cv2.FONT_HERSHEY_SIMPLEX, .6, text_color, 1, cv2.LINE_AA)
        text = "dX:" + str(dX) + " dY:" + str(dY)
        cv2.putText(preview, text, (x-r, y+r), cv2.FONT_HERSHEY_SIMPLEX, .6, text_color, 1, cv2.LINE_AA)

        print("-----------------")
        # print(json.dumps(ret))

        text = "picture width: " +str(image.shape[1]) + "  height: " + str(image.shape[0]) + ", found " + str(len(circles)) + " circle(s), took " + str(delta) + "ms"
        cv2.putText(preview, text, (10, image.shape[0]-14), cv2.FONT_HERSHEY_SIMPLEX, .5, text_color, 1, cv2.LINE_AA)



        # if show_preview:
        #     cv2.imshow("output", preview) # numpy.hstack([image, output]))

    return ret, preview
    # rc, jpeg_pic = cv2.imencode(".jpg", preview)
    # ret_pic = jpeg_pic.tobytes()
    # return ret, ret_pic



# if __name__ == '__main__':
#     logging.info("starting flask")
#     logging.error("asdf")
import cv2
capture = cv2.VideoCapture(0)
capture.set(3,800)  # width
capture.set(4,400) # height
while (True):
    # ret, frame = capture.read()
    print();
    print()
    ret, frame = capture.read()
    frame = cv2.rotate(frame, rotateCode=cv2.ROTATE_180)
    ret, preview = from_pic_get_circles(frame, show_preview=False)
    pprint(ret)
    # preview = cv2.resize(preview, (800,420))
    cv2.imshow('video', preview)
    if cv2.waitKey(1) == 27:
        break
    sleep(0.01)
capture.release()
cv2.destroyAllWindows()
