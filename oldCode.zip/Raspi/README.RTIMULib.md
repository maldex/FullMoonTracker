https://kingtidesailing.blogspot.com/2016/02/how-to-setup-mpu-9250-on-raspberry-pi_25.html

sudo pip3 install RTIMULib 
RTIMULibCal


# download and compile 
```
sudo apt-get install -y cmake python3-dev octave uuid-dev libicu-dev qt4-qmake libqt4-dev
sudo chown -R `whoami` /usr/local/src
pushd /usr/local/src
git clone https://github.com/richards-tech/RTIMULib2.git
cd RTIMULib2/Linux

mkdir build
cd build
cmake ..
make -j$(nproc)
sudo make install
sudo ldconfig

cd ../python 
python3 setup.py build
sudo python3 setup.py install
#sudo python2 setup.py install

popd 
```

# run a calibration
```
cp -r /usr/local/src/RTIMULib2/RTEllipsoidFit/ ./
cd RTEllipsoidFit
RTIMULibCal
cp RTIMULib.ini ..
cd ..

```



