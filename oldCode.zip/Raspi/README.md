Raspi Stuff
# Raspi setup see [here](http://gitlab.gebaschtel.ch/Elektronik/RaspI2C/blob/master/README.md)

### install additional stuff 
```
#sudo apt-get install -y python3-opencv
sudo pip3 install flask simplejson numpy yattag hurry.filesize adafruit-ads1x15 tinkerforge
```
### rtsp
```
sudo apt-get install -y git cmake liblog4cpp5-dev libv4l-dev libasound2-dev libalsaplayer-dev libclalsadrv-dev libdssialsacompat-dev
sudo setfacl -m u:`whoami`:rwX /usr/local/src/
pushd /usr/local/src
git clone https://github.com/mpromonet/v4l2rtspserver.git
cd v4l2rtspserver/
cmake .
make
sudo make install
popd
```

### Services
```bash
cd ~/AutoLunaObs/Raspi/
python3 6660-CamService.py &
python3 6662-JoyService.py &
python3 6664-TfService.py &

```
### install opencv

### compile OpenCV
credits to [pyimagesearch](https://www.pyimagesearch.com/2019/09/16/install-opencv-4-on-raspberry-pi-4-and-raspbian-buster/)
#### increase swap-space
while this is generally a stupid idea, we need some additional memory while compiling opencv
```bash
sudo sed -i -e 's/^CONF_SWAPSIZE=.*$/CONF_SWAPSIZE=2048/g' /etc/dphys-swapfile
sudo /etc/init.d/dphys-swapfile restart
```
#### install compiler and required libraries
```bash
sudo apt-get install -y build-essential cmake pkg-config \
    libjpeg-dev libtiff5-dev libpng-dev \
    libavcodec-dev libavformat-dev libswscale-dev libv4l-dev \
    libxvidcore-dev libx264-dev \
    libfontconfig1-dev libcairo2-dev \
    libgdk-pixbuf2.0-dev libpango1.0-dev \
    libgtk2.0-dev libgtk-3-dev \
    libatlas-base-dev gfortran \
    libhdf5-dev libhdf5-serial-dev libhdf5-103 \
    python3-pyqt5 python3-dev python3-pip \
    libavresample4 libavresample-dev libopenjp3d7 # libqtgui4 libqtwebkit4 libqt4-test  libjasper-dev
    
##############
    sudo sed -i 's/CONF_SWAPSIZE=.*/CONF_SWAPSIZE=2048/g' /etc/dphys-swapfile
    sudo /etc/init.d/dphys-swapfile restart

    sudo apt-get -y purge wolfram-engine
    sudo apt-get -y purge libreoffice*
    sudo apt-get -y clean
    sudo apt-get -y autoremove

    sudo apt -y update

    sudo apt-get -y remove x264 libx264-dev
     
    ## Install dependencies
    sudo apt-get -y install build-essential checkinstall cmake pkg-config yasm
    sudo apt-get -y install git gfortran
    sudo apt-get -y install libjpeg8-dev libjasper-dev libpng12-dev
     
    sudo apt-get -y install libtiff5-dev
     
    sudo apt-get -y install libtiff-dev
     
    sudo apt-get -y install libavcodec-dev libavformat-dev libswscale-dev libdc1394-22-dev
    sudo apt-get -y install libxine2-dev libv4l-dev
    cd /usr/include/linux
    sudo ln -s -f ../libv4l1-videodev.h videodev.h
    cd $cwd
     
    sudo apt-get -y install libgstreamer0.10-dev libgstreamer-plugins-base0.10-dev
    sudo apt-get -y install libgtk2.0-dev libtbb-dev qt5-default
    sudo apt-get -y install libatlas-base-dev
    sudo apt-get -y install libmp3lame-dev libtheora-dev
    sudo apt-get -y install libvorbis-dev libxvidcore-dev libx264-dev
    sudo apt-get -y install libopencore-amrnb-dev libopencore-amrwb-dev
    sudo apt-get -y install libavresample-dev
    sudo apt-get -y install x264 v4l-utils
     
    # Optional dependencies
    # sudo apt-get -y remove libprotobuf-dev protobuf-compiler libprotoc-dev libprotobuf-c-dev python3-protobuf
    sudo apt-get -y install libgoogle-glog-dev libgflags-dev
    sudo apt-get -y install libgphoto2-dev libeigen3-dev libhdf5-dev doxygen
    
    sudo apt-get -y install python3-dev python3-pip
    sudo -H pip3 install -U pip numpy dlib
    sudo apt-get -y install python3-testresources

    sudo apt-get -y install libglu1-mesa-dev freeglut3-dev 
    sudo apt-get -y install libceres-dev libtesseract-dev libtesseract4 libjemalloc-dev libjemalloc2
    sudo apt-get -y install eigensoft libeigen2-dev libeigen3-dev liblapack-dev liblapacke-dev libgstreamermm-1.0-dev doxygen libcaffe-cpu-dev golang-glog-dev gstreamer0.10-plugins-base-apps gstreamer1.0-dev gstreamer1.0-tools
 

```
#### download OpenCV
```bash
#sudo setfacl -m u:`whoami`:rwX /usr/local/src/
#pushd /usr/local/src
OPENCV_VERSION="4.7.0"
rm opencv*.zip
wget -O opencv.zip https://github.com/opencv/opencv/archive/${OPENCV_VERSION}.zip
wget -O opencv_contrib.zip https://github.com/opencv/opencv_contrib/archive/${OPENCV_VERSION}.zip
unzip opencv.zip
unzip opencv_contrib.zip
mv -v opencv-${OPENCV_VERSION} opencv
mv -v opencv_contrib-${OPENCV_VERSION} opencv_contrib
```
#### compile OpenCV
```bash

rm -rf ~/opencv/build; mkdir ~/opencv/build
cd ~/opencv/build
# detect capabilities and optimize upcomming compile
time cmake -D CMAKE_BUILD_TYPE=RELEASE \
    -D CMAKE_INSTALL_PREFIX=/usr/local \
    -D OPENCV_EXTRA_MODULES_PATH=~/opencv_contrib/modules \
    -D ENABLE_NEON=ON \
    -D ENABLE_VFPV3=ON \
    -D BUILD_TESTS=OFF \
    -D INSTALL_PYTHON_EXAMPLES=OFF \
    -D OPENCV_ENABLE_NONFREE=ON \
    -D CMAKE_SHARED_LINKER_FLAGS=-latomic \
    -D BUILD_EXAMPLES=OFF ..
# watchout for 
#   - Python 3 interpreter is /usr/bin/python3
#   - OpenCV Modules do include Non-free algorithms: YES

# actually compile. Be aware:
# this will take ~1 1/2hours on a Raspi4, and up to 6hours on a Raspi3 B+
time make -j4 

# install this compiled version
sudo make install && sudo ldconfig
```

#### test
```bash
# this should report the same version as previously downloaded
echo -e "import cv2\nprint(cv2.__version__)" | python3
```

#### decrease swap-space
```bash
sudo sed -i -e 's/^CONF_SWAPSIZE=.*$/CONF_SWAPSIZE=100/g' /etc/dphys-swapfile
sudo /etc/init.d/dphys-swapfile restart
```


### bugfixes
if `echo -e "import cv2\nprint(cv2.__version__)" | python3` reports an error, try:
```bash
sudo apt-get reinstall libopenjp2-7

cd ~/opencv/build
sudo make uninstall
sudo make install

sudo ldconfig
```