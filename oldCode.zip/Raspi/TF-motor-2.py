#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from tinkerforge.ip_connection import IPConnection
from tinkerforge.brick_silent_stepper import BrickSilentStepper
import threading

horizontalUID = "6mV328"
verticalUID = "6sQeeJ"

from sys import argv


class TF_motor():
    def __init__(self, ipcon, uid):
        self._ipcon, self.uid = ipcon, uid

        self._ss = BrickSilentStepper(self.uid, self._ipcon)
        self._ss.set_motor_current(800)  # 800mA
        self._ss.set_step_configuration(self._ss.STEP_RESOLUTION_32, True)  # 1/8 steps (interpolated)

        # Slow acceleration (500 steps/s^2),
        # Fast deacceleration (5000 steps/s^2)
        self._ss.set_speed_ramping(0, 0)
        self._ss.enable()  # enable motor power

        self.next_velocity = 5000
        self.next_steps = 0


    def __del__(self):
        try:
            self._ss.disable()
        except Exception as e:
            pass

    def drive(self, steps, velocity=5000):
        self._ss.set_max_velocity(velocity)  # Velocity 2000 steps/s

        self._ss.set_steps(steps)  # Drive 60000 steps forward

    def get_remaining(self):
        return self._ss.get_remaining_steps()


if __name__ == "__main__":
    ipcon = IPConnection()
    ipcon.connect("127.0.0.1", 4223)

    hm = TF_motor(ipcon, horizontalUID)
    vm = TF_motor(ipcon, verticalUID)

    steps_h = int(argv[1])
    if abs(steps_h)>50000 : exit(-1)

    steps_v = int(argv[2])
    if abs(steps_v)>50000 : exit(-1)

    hm.drive(steps_h)
    vm.drive(steps_v)

    while hm.get_remaining() != 0 or vm.get_remaining() != 0:
        print(str(hm.get_remaining()) + " - " + str(vm.get_remaining()))

    ipcon.disconnect()