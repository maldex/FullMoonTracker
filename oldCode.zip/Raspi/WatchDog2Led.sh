#!/bin/bash
function WatchDogToLed(){
    wdtlPin=$1 
    wdtlCmd=$2
    if [ ! -e /sys/class/gpio/gpio${wdtlPin} ]; then
        echo ${wdtlPin} > /sys/class/gpio/export 
        echo out > /sys/class/gpio/gpio${wdtlPin}/direction
    fi

    echo 1  > /sys/class/gpio/gpio${wdtlPin}/value
    ${wdtlCmd}
    r=$?
    echo 0  > /sys/class/gpio/gpio${wdtlPin}/value    
    if [ "${r}" != "0" ]; then
        for i in `seq 1 4`; do 
            sleep 0.1
            echo $((${i}%2)) > /sys/class/gpio/gpio${wdtlPin}/value
        done
    fi
    return ${r}
}

while true; do
    sleep 3
    WatchDogToLed 21 "i2cdetect -y 1" > /dev/null 2>&1 &
    WatchDogToLed 16 "ping -c1 -w1 `ip route | grep "default" | awk '{ print $3; }'`"  > /dev/null 2>&1 &
done 