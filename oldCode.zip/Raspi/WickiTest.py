import io
import time
import logging

import picamera
import picamera.array

import cv2

from tinkerforge.ip_connection import IPConnection
from tinkerforge.brick_silent_stepper import BrickSilentStepper


TINKERFORGE_HOST = "localhost"
TINKERFORGE_PORT = 4223
UID_VERTICAL = "6sQeeJ"
UID_HORIZONTAL = "6mV328"

# Motors wraps both motor axis
class Motors():
    # Creates a new Motors instance. Assumes 'horizontal' and 'vertical' are
    # fully configured and connected 'BrickSilentStepper's.
    def __init__(self, horizontal, vertical):
        logging.debug("Motors(horizontal=%s, vertical=%s)",
            horizontal.get_identity(), vertical.get_identity())
        self.h = horizontal
        self.v = vertical

    def move(self, dx, dy):
        print(dx, dy)
        ss.enable()
        self.h.set_steps(dx * 10)
        print(self.h.get_remaining_steps())
        while abs(self.h.get_remaining_steps()) > 0:
            print(self.h.get_remaining_steps())
            time.sleep(0.1)

        self.v.set_steps(dy * 10)
        print(self.v.get_remaining_steps())
        while abs(self.v.get_remaining_steps()) > 0:
            print(self.v.get_remaining_steps())
            time.sleep(0.1)

        ss.disable()


class Camera():
    def __init__(self, picam):
        self.picam = picam
    
    def capture_stream(self):
        self.picam.start_preview()
        with picamera.array.PiRGBArray(self.picam) as stream:
            while True:
                self.picam.capture(stream, format='bgr')
                yield stream.array
                stream.seek(0)
                stream.truncate()

class Detector():
    def __init__(self):
        pass

    def detect(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, (1024, 768), interpolation = cv2.INTER_AREA) 


        cv2.imwrite('/tmp/gray.jpg', gray)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=1.8,
            minDist=int(gray.shape[0]/16),
            minRadius=int(gray.shape[0]/64),
            maxRadius=int(gray.shape[0]/2))
        if circles is not None:
            x, y, r = max(circles[0], key=lambda i: i[2])
            dX = -int(gray.shape[1]/2 - x )
            dY = -int(gray.shape[0]/2 - y )
            return dX, dY

        return 0, 0

class Looper():
    def __init__(self, camera, detector, motors):
        self.camera = camera
        self.detector = detector
        self.motors = motors

    def loop(self):
        for frame in self.camera.capture_stream():
            dx, dy = self.detector.detect(frame)
            if dx != 0 and dy != 0:
                self.motors.move(dx, dy)


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    # initialize picam (with default values)
    picam = picamera.PiCamera(resolution=(3280, 2464))
    cam = Camera(picam)

    # initialize circle detector
    detector = Detector()

    # initialize motors
    ipconn = IPConnection()
    ipconn.connect(TINKERFORGE_HOST, TINKERFORGE_PORT)
    h = BrickSilentStepper(UID_HORIZONTAL, ipconn)
    v = BrickSilentStepper(UID_VERTICAL, ipconn)
    for ss in [h, v]:
        ss.set_motor_current(800) # 800mA
        ss.set_step_configuration(ss.STEP_RESOLUTION_32, True) # 1/32 steps (interpolated)
        ss.set_max_velocity(5000) # Velocity 5000 steps/s
    motors = Motors(h, v)

    l = Looper(cam, detector, motors)
    l.loop()
