#!/usr/bin/env python3

#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime
import threading, copy, time, logging, os, sys
import simplejson as json
from flask import Flask, request, Response, render_template, send_from_directory, send_file, abort, redirect
from yattag import Doc
linesep = os.linesep

from urllib.request import Request, urlopen  # Python 3
import urllib.error
import math, os, time
from pprint import pprint

app = Flask(__name__, static_url_path='')
app.logger.setLevel(logging.DEBUG)
logging.basicConfig(level=logging.DEBUG)


import pygame
from time import sleep
from urllib.request import Request, urlopen  # Python 3
os.putenv('DISPLAY', ':0')


def synchronized_method(method):
    outer_lock = threading.Lock()
    lock_name = "__" + method.__name__ + "_lock" + "__"

    def sync_method(self, *args, **kws):
        with outer_lock:
            if not hasattr(self, lock_name): setattr(self, lock_name, threading.Lock())
            lock = getattr(self, lock_name)
            with lock:
                return method(self, *args, **kws)

    return sync_method



class MyJoyStick(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self._alive = True
        self._data = {"error": "no data from sensor"}
        self.interval = 0.01

        os.putenv('SDL_VIDEODRIVER', 'fbcon')
        # pygame.display.init()
        pygame.init()
        # screen = pygame.display.set_mode((400,300))

        # joysticks = []
        # while len(joysticks) == 0 :
        #     sleep(1)
        joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]
        while len(joysticks) == 0:
            raise(Exception, "no Joystick found")

        print(joysticks)
        #j = pygame.joystick.Joystick(0)
        self.stick = joysticks[0]
        self.stick.init()
        print('Initialized Joystick : %s' % self.stick.get_name())

    @synchronized_method
    def _get_aliveness(self):
        return self._alive

    @synchronized_method
    def stop(self):
        self._alive = False

    @synchronized_method
    def set_data(self, data):
        self._data = data

    @synchronized_method
    def get_data(self):
        return copy.deepcopy(self._data)

    def run(self):
        print("thread: starting")
        self.sensor_reader()
        print("thread: byebye")

    def sensor_reader(self):
        while self._get_aliveness():
            pygame.event.pump()
            ret = {
                'timestamp': time.time(),
                'axes'   : [ self.stick.get_axis(i) for i in range(0,self.stick.get_numaxes()) ],
                'balls'  : [ self.stick.get_ball(i) for i in range(0,self.stick.get_numballs()) ],
                'hats'   : [ self.stick.get_hat(i) for i in range(0,self.stick.get_numhats()) ],
                'buttons': [ self.stick.get_button(i) for i in range(0,self.stick.get_numbuttons()) ],
                'timestamp': time.time()
            }
            # print(axes,balls,hats,buttons)
            self.set_data(ret)
            sleep(self.interval)

class WatchDog(threading.Thread):
    def __init__(self, url, interval=3, other_cb=None):
        threading.Thread.__init__(self)
        self.url, self.interval, self.other_cb = url, interval, other_cb
        self._alive = True

    @synchronized_method
    def _get_aliveness(self):
        return self._alive

    @synchronized_method
    def stop(self):
        self._alive = False

    def run(self):
        time.sleep(self.interval)
        logging.info("wd-thread: starting")
        last_timestamp = 0
        while self._get_aliveness():
            time.sleep(self.interval)
            logging.debug("wd-thread: checking " + self.url)
            try:
                answer = urlopen(self.url, timeout=1)
            except urllib.error.HTTPError as e:
                logging.error("wd-thread: HTTPError: " + str(e) )
                self.killall()
                break
            except urllib.error.URLError as e:
                logging.error("wd-thread: URLError: " + str(e))
                self.killall()
                break
            except ConnectionResetError as e:
                logging.error("wd-thread: ConnectionResetError: " + str(e))
                self.killall()
                break

            try:
                data = json.loads(answer.read())
                pprint(data)
                timestamp = data['timestamp']
                if last_timestamp == 0:
                    last_timestamp = timestamp
            except TypeError as e:
                logging.warn("wd-thread: Warn: could not extract Timestamp " + str(data))
                timestamp = 666
            except KeyError as e:
                logging.warn("wd-thread: Warn: could not extract Timestamp " + str(data))
                timestamp = 667
            if (timestamp - last_timestamp) > (self.interval * 2): # not updating anymore
                logging.error("wd-thread: Error: timestamp stale at " + str(timestamp))
                self.killall()
                break

            # else all good
            last_timestamp = timestamp
        logging.info("wd-thread: byebye")

    def killall(self):
        self.other_cb()
        self.stop()
        os._exit(0)
        sys.exit(0)



@app.route("/")
def get_data():
    return Response(json.dumps(MyStick.get_data(), indent=True), mimetype='text/json;charset=UTF-8')


if __name__ == '__main__':
    logging.info("starting stick")
    MyStick = MyJoyStick()
    MyStick.start()
    logging.info("starting watchdog")
    MyWd = WatchDog("http://127.0.0.1:6662", interval=3, other_cb=MyStick.stop)
    MyWd.start()
    logging.info("starting flask")
    app.run(host='0.0.0.0', port=6662, debug=False)
    MyStick.stop()

print("tschuess")



print("tschuess")