#!/usr/bin/python3
# -*- coding: utf-8 -*-


import cv2
import numpy
import time
import urllib
import simplejson as json
from datetime import datetime
from urllib.request import Request, urlopen  # Python 3
from pprint import pprint

from flask import Flask, request, Response, render_template, send_from_directory, send_file, abort, redirect
from yattag import Doc
import logging, os
import urllib.error
import simplejson as json

os.environ["DISPLAY"]=":0"
os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp'
cap = cv2.VideoCapture("rtsp://127.0.0.1:8554/unicast",cv2.CAP_FFMPEG)
while cap.isOpened:
    ret, frame = cap.read()
    if ret == False:
        print("Frame is empty")
        break;
    else:
        rsized = cv2.resize(frame, (960, 540))
        cv2.imshow('VIDEO', rsized)
        cv2.waitKey(1)